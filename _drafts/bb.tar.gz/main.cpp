#include "boundedbuffer.h"
#include <iostream>
#include <atomic>
#include <thread>

BoundedBuffer<std::string> buffer(10);

std::atomic_bool dep;
std::atomic_bool fet;

void testDeposit() {
    char id = rand() % 50 + 50;
    for(auto i = 0u; i < 5u; ++i) {
        std::string str = id+std::to_string((i));
        buffer.deposit(str);
        std::cout << "Dep " << str << std::endl;
    }
}

void testFetch() {
    char id = rand() % 50 + 50;
    for(auto i = 0u; i < 5u; ) {
        std::cout << id << " fetchd " << buffer.fetch() << std::endl;
    }
}

int main(int argc, char *argv[])
{
    dep = fet = true;
    srand(time_t(nullptr));

    std::thread d0(&testDeposit);
    std::thread f0(&testFetch);
    //testDeposit();
    //testFetch();
    return 0;
}
