#ifndef SEMAPHORE_WEAK_H
#define SEMAPHORE_WEAK_H
#include <mutex>
#include <condition_variable>
using namespace std;

/*
 * @class SemaphoreWeak
 * @brief Very simple weak semaphore implementation.
 * Weak in that there is no guarentee that the first thread
 * to wait will be the first thread let through.
 * @remarks Because this is a weak semaphore, we run the risk of starvation.
 */
class SemaphoreWeak
{
public:
    /*
     * @brief Constructs a weak semaphore.
     * @param count The starting count of the semaphore.
     */
    SemaphoreWeak(unsigned int count = 0);

    //! Increments count and notifies one waiting thread.
    void post();

    //! Block until count is greater than 0, then decrement count.
    void wait();

private:
    mutex mutex_;
    condition_variable cv_;
    unsigned int count_;
};
#endif // SEMAPHORE_WEAK_H
