#ifndef BOUNDED_BUFFER_H
#define BOUNDED_BUFFER_H

#include <vector>
#include <condition_variable>

#include "semaphore_weak.h"

/*
 * @class BoundedBuffer
 * @brief Simple threadsafe implementation of a bounded buffer.
 */
template <typename T>
class BoundedBuffer {
public:
        /*
	 * @brief Constructs a bounded buffer.
	 * @param size The number of elements the buffer can hold.
	 * @remarks T must have a default ctor to use this ctor.
	 */
        BoundedBuffer<T>(size_t size);

	/*
	 * @Constructs a bounded buffer.
	 * @param size The number of elements the buffer can hold.
	 * @param val The default value to fill the buffer with.
	 * @remarks It doesn't matter what val is, all will be overwritten before ever being read.
	 */
	BoundedBuffer<T>(size_t size, T val);

	/*
	 * @brief Puts an item into the buffer.
	 * @param item The object to be deposited.
	 */
	void deposit(T item);

	/*
	 * @brief Retrieves an object from the buffer.
	 * @return The item at the front of the buffer.
	 */
	T fetch();

	//! Returns true if there are no items in the buffer.
	bool empty() const;

private:

	//! Index of front of buffer.
	size_t front_;
	//! Index of back of buffer.
	size_t rear_;
	//! Number of items currently in the buffer.
	size_t count_;

	//! Size of the buffer.
	const size_t capacity_;

	//! Using vector here like a runtime-sized array.
	std::vector<T> buffer_;

	//! How many items can be deposited before buffer is full.
	SemaphoreWeak notFull_;

	//! How many items can be fetched before buffer is empty.
	SemaphoreWeak notEmpty_;
};

#include "boundedbuffer.inl"
#endif
