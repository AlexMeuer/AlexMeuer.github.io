#include "semaphore_weak.h"

SemaphoreWeak::SemaphoreWeak(unsigned int count) :
    count_(count)
{
    //empty ctor body
}

void SemaphoreWeak::post()
{
    std::unique_lock<std::mutex> lock(mutex_);

    ++count_;

    // Wake a waiting thread
    cv_.notify_one();
}

void SemaphoreWeak::wait()
{
    std::unique_lock<std::mutex> lock(mutex_);

    while(count_ == 0)
    {
        cv_.wait(lock);
    }

    --count_;
}
