#ifndef _TEXTURE_ATLAS_H
#define _TEXTURE_ATLAS_H

#include <SDL.h>
#include <SDL_image.h>
#include <fstream>
#include <iostream>
#include "json/json.h"

class TextureAtlas {
public:
	TextureAtlas(const char* jsonPath, SDL_Renderer* renderer);
	~TextureAtlas();

	SDL_Rect* operator[](std::string const &key) const; //get subtexture by name
	SDL_Texture* getTexture() const;

private:
	std::map<std::string, SDL_Rect*> mSubtextures;
	SDL_Texture* mTexture;
	SDL_Surface* mSurface;

	void loadTexture(const char* path, SDL_Renderer* renderer);
};
#endif