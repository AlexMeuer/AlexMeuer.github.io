#include "TextureAtlas.h"

TextureAtlas::TextureAtlas(const char* jsonPath, SDL_Renderer* renderer) {
	std::ifstream fileStream = std::ifstream(jsonPath, std::ifstream::binary);

	Json::Value root;
	fileStream >> root;   //Read the file

	//Output the json file to console
	std::cout << root.toStyledString() << std::endl;

	//Load the texture specified in the json file.
	loadTexture(root["TextureAtlas"]["imagePath"].asCString(), renderer);

	//Find the array of subtextures.
	const Json::Value subtextures = root["TextureAtlas"]["SubTexture"];
	std::cout << "Loading subtextures..." << std::endl;

	for (int index = 0; index < subtextures.size(); ++index)
	{
		//get the name of the subtexture
		std::string key = subtextures[index]["name"].asString();

		//get the source rectangle of the subtexture
		SDL_Rect* rect = new SDL_Rect();
		rect->x = atoi(subtextures[index]["x"].asCString());	//roundabout conversion because Shoebox writes all values as strings
		rect->y = atoi(subtextures[index]["y"].asCString());
		rect->w = atoi(subtextures[index]["width"].asCString());
		rect->h = atoi(subtextures[index]["height"].asCString());

		printf("Subtexture: Name: %s\tX: %d\tY: %d\tW: %d\tH: %d\n", key.c_str(), rect->x, rect->y, rect->w, rect->h);

		//add the name and rectangle to the map
		mSubtextures[key] = rect;
	}
}

TextureAtlas::~TextureAtlas() {
	for (auto entry : mSubtextures)
	{
		delete entry.second;
	}
}

SDL_Rect* TextureAtlas::operator[](std::string const& key) const {
	return mSubtextures.at(key);
}

SDL_Texture* TextureAtlas::getTexture() const {
	return mTexture;
}

void TextureAtlas::loadTexture(const char* path, SDL_Renderer* renderer) {
	mSurface = IMG_Load(path);

	if (mSurface == nullptr)
	{
		printf("Unable to load image %s! SDL_image Error: %s\n", path, IMG_GetError());
	}
	else
	{
		//Create texture from surface pixels
		mTexture = SDL_CreateTextureFromSurface(renderer, mSurface);
		if (mTexture == nullptr)
		{
			printf("Unable to create texture from %s! SDL Error: %s\n", path, SDL_GetError());
		}
		else
		{
			printf("Loaded image %s successfully.\n", path);
		}


		//Get rid of old loaded surface
		SDL_FreeSurface(mSurface);

	}
}