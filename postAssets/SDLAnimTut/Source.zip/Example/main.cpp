#pragma comment(lib, "SDL2.lib")	//tell the compiler that we depend on the SDL libraries
#pragma comment(lib, "SDL2_image.lib")

#include <SDL.h>
#include <SDL_image.h>
#include <iostream>
#include "TextureAtlas.h"

int wmain() {
	if (SDL_Init(SDL_INIT_VIDEO) < 0)    {
		std::cout << "SDL could not initialize! SDL_Error: " << SDL_GetError() << std::endl;
		system("timeout 10");   //wait 10 seconds
		return 1;    //exit with an error code
	}

	SDL_Window* window = SDL_CreateWindow("Example", 100, 100, 600, 480, NULL);
	SDL_Renderer* renderer = SDL_CreateRenderer(window, NULL, NULL);

	//Create our atlas from example.json. The renderer will be used to load the texture.
	TextureAtlas texAtlas = TextureAtlas("example.json", renderer);

#pragma region Possible_Sprite_class
	//The following fields could be made into a class for reusability.
	SDL_Texture* texture;
	const unsigned int NUM_FRAMES = 8;
	unsigned int currentFrame = 0;
	SDL_Rect* frames[NUM_FRAMES];	//Consider using an std::vector<SDL_Rect*> if you don't know the number of frames at compile time.

	//In my example.json, the name of each frame is "frame[FRAME_NUMBER].png", so that's how I'm accessing them from the atlas.
	std::string prefix = "frame";
	std::string postfix = ".png";
	for (int i = 0; i < NUM_FRAMES; ++i)
	{
		//Populate our frame array. If you're making a sprite class, put this in the contructor and pass in a reference to the atlas.
		frames[i] = texAtlas[prefix + std::to_string(i) + postfix];
	}

	SDL_Rect dest;	//Where the texture will be drawn to on the screen
	dest.x = 100;
	dest.y = 100;
	dest.w = frames[0]->w;
	dest.h = frames[0]->h;

	texture = texAtlas.getTexture();	//Get the packed texture from the atlas.  
#pragma endregion


	SDL_SetRenderDrawColor(renderer, 255, 255, 255, 0);	//We'll be clearing the screen to black.
	while (true)
	{
		//Homework: Implement a fixed timestep to control the framerate. Optionally, if making a Sprite class, implement a frame delay to animate them at different speeds.

		//Cycle through frames
		if (++currentFrame == NUM_FRAMES)
		{
			currentFrame = 0;
		}

		//Clear the screen
		SDL_RenderClear(renderer);

		SDL_RenderCopy(renderer, texture, frames[currentFrame], &dest); //Copy the image to the rendering object.

		//Update the screen with rendering operations
		SDL_RenderPresent(renderer);
	}

}