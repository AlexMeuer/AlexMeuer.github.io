package com.example.IntentsLR;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Example extends Activity {
    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }

    //called when the button is clicked. View 'v' is the button itself
    public void onBtnClick(View v) {

        //getApplicationContext can be replaced with keyword 'this' (Activity extends context)
        Intent myIntent = new Intent(getApplicationContext(), newActivity.class);

        //we can extract the "passedString" VALUE on the other end with the Intent.getStringExtra(KEY) function on the other end
        myIntent.putExtra("myString", "passedString");

        startActivity(myIntent);
    }
}
