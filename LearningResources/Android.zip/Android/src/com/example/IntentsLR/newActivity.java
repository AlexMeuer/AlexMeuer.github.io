package com.example.IntentsLR;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class newActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.newactivitylayout);


        //get the string we passed to this activity and display it on the screen
        Intent intent = getIntent();
        TextView tv = (TextView)findViewById(R.id.exampleTV);
        tv.setText(intent.getStringExtra("myString"));
    }
}
