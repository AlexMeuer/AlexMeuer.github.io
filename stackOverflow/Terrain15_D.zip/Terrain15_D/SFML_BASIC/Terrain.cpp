﻿#include "stdafx.h"
#include "SFML/OpenGL.hpp"
#include "Terrain.h"
#include <cmath>
#include <iostream>

Terrain::Terrain(void)
{
	if (LoadFromFile("test_map.png"))
	{
		std::cout << "HeightMap Loaded" << std::endl;
	}

	gridWidth=100;
	gridDepth=100;

	terrWidth=50; //size of terrain in world units
	terrDepth=50;
	vertices=NULL;
	colors=NULL;	
	
	//num squares in grid will be width*height, two triangles per square
	//3 verts per triangle
	 numVerts=gridDepth*gridWidth*2*3;

}
Terrain::~Terrain(void)
{
	delete [] vertices;
	delete [] colors;
}

//interpolate between two values
float lerp(float start, float end, float t)
{
	return start+(end-start)*t;
}

void Terrain::setPoint(vector v,float x, float y, float z)
{
	v[0]=x;
	v[1]=y;
	v[2]=z;
}

//helper function to calculate height of terrain at a given point in space
//you will need to modify this significantly to pull height from a map
float Terrain::getHeight(float x, float y)
{
	//for the sample we will calculate height based on distance form origin
	float dist=sqrt(x*x+y*y);

	//center will be the highest point
	dist=30-dist;
	//put a nice curve in it
	dist*=dist;
	dist*=dist;
	//whoah, way too high, make it smaller
	dist/=50000;

	return dist;
}

float Terrain::getHeightMapping(float x, float y)
{
	float height;

	float Depth = image.getSize().x;
	float Width = image.getSize().y;
	int size = Depth * Width;
	
	float imgPosDep = Depth / terrDepth;
	float imgPosWid = Width / terrWidth;

	x += 25;
	y += 25;

	x *= imgPosDep;
	y *= imgPosWid;

	const sf::Color px = image.getPixel(x, y);
	
	height = px.r/50.0;
	return height;
}

bool Terrain::LoadFromFile(const std::string& filename)
{
	/*if (!image.loadFromFile(filename))
		return false;
	return true;*/

	return image.loadFromFile(filename);
}

void Terrain::Init()
{
	delete [] vertices;//just in case we've called init before
	vertices=new vector[numVerts];
	delete [] colors;
	colors=new vector[numVerts];


	//interpolate along the edges to generate interior points
	for(int i=0;i<gridWidth-1;i++){ //iterate left to right
		for(int j=0;j<gridDepth-1;j++){//iterate front to back
			int sqNum=(j+i*gridDepth);
			int vertexNum=sqNum*3*2; //6 vertices per square (2 tris)
			float front=lerp(-terrDepth/2,terrDepth/2,(float)j/gridDepth);
			float back =lerp(-terrDepth/2,terrDepth/2,(float)(j+1)/gridDepth);
			float left=lerp(-terrWidth/2,terrWidth/2,(float)i/gridDepth);
			float right=lerp(-terrDepth/2,terrDepth/2,(float)(i+1)/gridDepth);
			
			/*
			back   +-----+	looking from above, the grid is made up of regular squares
			       |tri1/|	'left & 'right' are the x cooded of the edges of the square
				   |   / |	'back' & 'front' are the y coords of the square
				   |  /  |	each square is made of two trianlges (1 & 2)
				   | /   |	
				   |/tri2|
			front  +-----+
			     left   right
				 */

			//Triangle 1
			setPoint(vertices[vertexNum++], left, getHeightMapping(left, front), front);
			setPoint(colors[vertexNum], 1, 0, 0);

			setPoint(vertices[vertexNum++], right, getHeightMapping(right, front), front);
			setPoint(colors[vertexNum], 0, 1, 0);

			setPoint(vertices[vertexNum++], right, getHeightMapping(right, back), back);
			setPoint(colors[vertexNum], 0, 0, 1);

			//Triangle 2
			setPoint(vertices[vertexNum++], right, getHeightMapping(right, back), back);
			setPoint(colors[vertexNum], 1, 0, 0);

			setPoint(vertices[vertexNum++], left, getHeightMapping(left, back), back);
			setPoint(colors[vertexNum], 0, 1, 0);

			setPoint(vertices[vertexNum++], left, getHeightMapping(left, front), front);
			setPoint(colors[vertexNum], 0, 0, 1);
		}
	}

	calculateNormals();
}

void Terrain::Draw()
{
	glBegin(GL_TRIANGLES);
	for(int i = 0; i < numVerts; i++)
	{
		glNormal3fv(normals[i]);
		glColor3fv(colors[i]);
		glVertex3fv(vertices[i]);
	}
	glEnd();
}
/*
bool Terrain::LoadFromImage(const sf::Image& image, const sf::Image& gradient)
{
	if (gradient.getSize().y < 256)
		return false;

	gridDepth = image.getSize().x;
	gridWidth = image.getSize().y;

	const int size = gridDepth * gridWidth;

	unsigned char vertices[size];
	{
		const unsigned char* const px = image.getPixelsPtr();
		for (int i = 0; i<size; ++i)
			vertices[i] = px[i * 4];
	}

	return true;
}
*/

//	Returns the cross product of two GLfloat vector3s.
//	Vectors must contains at least 3 valid values, further values are ignored.
//	Passed vectors are unchanged.
void /*GLfloat**/ crossProduct(const GLfloat* const A, const GLfloat* const B, GLfloat* output) {
	//assert that vectors are not null
	_ASSERT(A && B && output);

	//GLfloat result[3];

	//cx = aybz − azby
	output[0] = (A[1] * B[2]) - (A[2] * B[1]);

	//cy = azbx − axbz
	output[1] = (A[2] * B[0]) - (A[0] * B[2]);

	//cz = axby − aybx
	output[2] = (A[0] * B[1]) - (A[1] * B[0]);

	//return result;
}

//	Normalizes a vector with any number of members!
//	Only checks that first and last members are valid.
//	Values of vector ARE MODIFIED.
void /*GLfloat**/ normalize(GLfloat* vector, size_t size = 3) {
	//assert that the vector and size are not NULL or 0
	_ASSERT(vector && size);

	float magnitude = 0.0;
	//get the magnitude of the vector
	for (size_t i = 0; i < size; i++) {
		magnitude += sqrtf(powf(vector[i], 2));
	}

	if (magnitude != 0) {

		//use the magnitude to normalize the vector
		for (size_t i = 0; i < size; i++) {
			vector[i] = vector[i] / magnitude;
		}

	}

	//return the resulting normalized vector
	//return normal;
}

//	Calculates the normals for every vertex
//	Modifies vertex array directly;
void Terrain::calculateNormals() {
	//assert that vertices array is not null
	_ASSERT(vertices[0] != NULL && vertices[numVerts-1] != NULL);

	normals = new vector[numVerts];

	//for every pair of triangles in the grid
	for (int i = 0; i < numVerts; i++){

		vector normalBuffer[6];

		//initialise normals to 0, clear junk values
		for (int j = 0; j < 3; j++) {
			normals[i][j] = 0;
		}

		//take two ajoining vertices and get their cross product
		//(TURNARY: if the next vertex would be in the next triangle, correct ourselves; stay in this one)

		//verts of current triangle
		crossProduct(vertices[i], vertices[i + 1 % 3 ? i + 1 : i - 2], normalBuffer[0]);
		crossProduct(vertices[i], vertices[i + 2 % 3 ? i + 2 : i - 1], normalBuffer[1]);

		//verts of other triangles
		crossProduct(vertices[i], vertices[i + gridWidth * 6 < numVerts ? i + gridWidth * 6 : numVerts - 1], normalBuffer[2]);
		crossProduct(vertices[i], vertices[i - gridWidth * 6 > 0 ? i - gridWidth * 6 : 0], normalBuffer[3]);
		crossProduct(vertices[i], vertices[i + 3 < numVerts ? i + 3 : numVerts - 1], normalBuffer[4]);
		crossProduct(vertices[i], vertices[i - 4 > 0 ? i - 4 : 0], normalBuffer[5]);

		//avaerage the normals
		for (int j = 0; j < 6; j++) {
			normals[i][0] += normalBuffer[j][0];
			normals[i][1] += normalBuffer[j][1];
			normals[i][2] += normalBuffer[j][2];
		}


		//normalize the vector, it is supposed to  be a normal after all...
		normalize(normals[i]);

		//TODO: calculate all normals for each vertex and normalize that one to get better normal
	}
}