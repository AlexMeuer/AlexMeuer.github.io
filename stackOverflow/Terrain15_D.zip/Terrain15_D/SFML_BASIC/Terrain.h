#pragma once
class Terrain
{
	//size of the mesh forming the terrain
	int gridWidth,gridDepth;
	int numVerts;
	//size of the terrain in world_coords
	float terrWidth,terrDepth;
	sf::Image image;

	typedef  GLfloat vector[3];
	//array of vertices for the grid(this will be a triangle list)
	//I know, very inefficient, but let's run before we walk
	vector *vertices;
	//vector<sf::Vector3f> Heights;
	vector *colors;

	vector *normals;

	float getHeight(float x, float y);
	void setPoint(vector, float, float,float);

	bool LoadFromFile(const std::string& filename);

	//bool LoadFromImage(const sf::Image& image, const sf::Image& gradient);
	//bool LoadFromFile(const std::string& filename, const std::string& gradient_name);
	float getHeightMapping(float x, float y);

	virtual void calculateNormals() final;

public:
	Terrain(void);
	~Terrain(void);

	void Init();
	void Draw();
};

