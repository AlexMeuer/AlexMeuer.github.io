#pragma comment(lib,"assimp.lib")
#include <assimp/cimport.h>
#include <assimp/scene.h>
#include <assimp/postprocess.h>



class Camera{
    static aiVector3D zero,yaxis,zaxis;
public:
    aiVector3D position;
    aiVector3D forward;
    aiVector3D up;
 
    float forwardSpeed;
    float roationSpeed;
     
    Camera():forwardSpeed(0.5f),roationSpeed(0.1f){}
 
    void Init(aiVector3D& p=zero, aiVector3D& f=zaxis, aiVector3D& u=yaxis){
        position=p;
        forward=f;
        up=u;
         
    }
 
	void Update(sf::Event e){//respond to keyboard events
		if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::D)){
                MoveLeftRight(+1);
            }

			if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::A)){
                MoveLeftRight(-1);
            }
 
            if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::W)){
                MoveForwardBack(1);
            }
            if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::S)){
                MoveForwardBack(-1);
            }

			if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::Q)){
                MoveUpDown(1);
            }
            if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::E)){
                MoveUpDown(-1);
            }
 
            if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::Right)){
                TurnRightLeft(1);
            }
            if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::Left)){
                TurnRightLeft(-1);
            }
            if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::Up)){
               TurnUpDown(1);
            }
            if ((e.type == sf::Event::KeyPressed) && (e.key.code == sf::Keyboard::Down)){
                TurnUpDown(-1);
 
            }
	
	}

#pragma region VectorMaths
	aiVector3D VectorCrossProduct(aiVector3D const &A, aiVector3D const &B) {
		//A x B = (a2b3 - a3b2, a3b1 - a1b3, a1b2 - a2b1); a vector quantity
		float x, y, z;
		x = (A.y * B.z) - (A.z * B.y);
		y = (A.z * B.x) - (A.x * B.z);
		z = (A.x * B.y) - (A.y * B.x);

		return aiVector3D(x, y, z);
	}

	//aiVector3D VectorNormalize(aiVector3D const &V) {
	//	//normal_V = V / magnitude_V
	//	return V / sqrtf((V.x * V.x) + (V.y * V.y) + (V.z * V.z));
	//}
#pragma endregion



    void MoveLeftRight(int dir){ //Dir=+1=>Right, dir=-1=> Left
		aiVector3D horizontal = VectorCrossProduct(forward, up).Normalize();
		position += (horizontal * (forwardSpeed*dir));
    }

	void MoveUpDown(int dir){ //Dir=+1=>Right, dir=-1=> Left
		position += (up * (forwardSpeed * dir));
    }
 
    void MoveForwardBack(int dir){ //Dir=+1=>Forward, dir=-1=> Back
 
        position += (forward*(forwardSpeed*dir));
    }
 
    void TurnRightLeft(float dir){ //Dir=+1=>Right, dir=-1=> Left
		aiQuaternion Q = aiQuaternion(up, dir * 0.1f);
		forward = Q.Rotate(forward);
		up = Q.Rotate(up);
	}
         
    void TurnUpDown(float dir){ //Dir=+1=>Up, dir=-1=> Down
		aiQuaternion Q = aiQuaternion(VectorCrossProduct(forward, up).Normalize(), dir * 0.1f);
		forward = Q.Rotate(forward);
		up = Q.Rotate(up);
    }
 
    void ViewingTransform(){
        gluLookAt(	position.x,position.y,position.z,// camera position
			position.x + forward.x, position.y + forward.y, position.z + forward.z, //look at this point //TODO: BUG here!! what is it ?? TODONE: ITS RIGHT HERE!!! I DONE FIXED IT!
					up.x, up.y, up.z); //camera up
    }
 
};

//create some default vectors
aiVector3D Camera::zero(0.0f);
aiVector3D Camera::yaxis(0.0f,1.0f,0.0f);
aiVector3D Camera::zaxis(0.0f,0.0f,1.0f);